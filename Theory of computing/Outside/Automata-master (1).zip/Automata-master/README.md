[![Stories in Ready](https://badge.waffle.io/dummer/automata.png?label=ready&title=Ready)](https://waffle.io/dummer/automata)
Automata
========

Implementation of DFA, NFA and eNFA into classes
