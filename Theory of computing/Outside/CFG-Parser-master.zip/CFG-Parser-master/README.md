## About Project

This is a C++ parser project that creates the Grammer of the Language according to given "grammar.txt" file. After creating grammar, the program reads each word in the "words.txt" file and decide if these words are in the Language defined by the grammar. If it is, then program will print "YES" and show all the paths. Otherwise, it will print "NO". At the end, the program will create a file named "result.txt" and write all the output on it.

## License

Read the LICENSE file.

Note: [Original writer of this project](https://github.com/karakayasemi)
