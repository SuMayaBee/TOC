#include<bits/stdc++.h>
using namespace std;
 
int main(){
    string str;
    char 
    return 0;
}