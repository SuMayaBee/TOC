#include <stdio.h>

// This is a single-line comment
int main() {
    /* This is a multi-line comment */
    printf("Hello, world!\n"); // Another single-line comment

    printf("Hello, world again!\n"); /* Another comment */

    return 0;

    /* This is another comment */
}
