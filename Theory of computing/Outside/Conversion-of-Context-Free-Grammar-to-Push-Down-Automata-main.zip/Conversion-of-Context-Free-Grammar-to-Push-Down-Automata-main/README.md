# Conversion-of-Context-Free-Grammar-to-Push-Down-Automata
Project was created with 3 other students that can convert any given context free grammar into push-down automata and display the push-down automata in ASCII graphs
TO RUN: the grammar.txt file must be in the particular form of Context-Free Grammar as shown below. 
S abA
A aS
C AS

Note: 
The capital letters are non-terminal symbols
The lowercase letters are terminal symbols 
The space between the symbols determines the production rule
