#include<bits/stdc++.h>
using namespace std;
int main()
{

    printf("Enter the length\n");
    int len;
    cin>>len;
    printf("Enter number of cut\n");
    int n;
    cin>>n;
    int location[n+1];

    for(int i=1;i<=n;i++)
    {
        cin>>[i];
    }

}

