#include<bits/stdc++.h>
using namespace std;
int main()
{
    printf("Thsi is a text here\n");
    printf("Enter the calue of a\n");
    int a,b;
    scanf("%d",&a);
    printf("ENter the value of b\n");
    scanf("%d",&b);
    printf("Sumassion of a and b is %d\n",a+b);

    return 0;
}