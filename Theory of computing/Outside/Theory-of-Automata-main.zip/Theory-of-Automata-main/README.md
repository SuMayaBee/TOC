# Theory-of-Automata
this repository will keep all of my codes i did in Theory of Automata course (SE 312), during my 3rd semester in Institute of Information Technology, University of Dhaka.  

list of topic: 
1) dfa code accepting a certain string 
2) nfa to dfa conversion 
3) enfa to dfa conversion 

** may be extended later 



short description of each topic: 
1) ** later 
2) ** later 
3) ** later




 
  
