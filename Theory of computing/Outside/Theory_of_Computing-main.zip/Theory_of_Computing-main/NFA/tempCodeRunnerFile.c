
    // if(initialState== FinalState)
    // {
    //     isNFA= true;
    // }