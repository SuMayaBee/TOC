#ifndef __HEADER_H
#define __HEADER_H
#include <map>
#include <iostream>
#include <set>
using namespace std;

map<char, set <string>> rule;
set<char> terminal; //A B C D
set<char> nonTerminal; //a b c d 

#endif


