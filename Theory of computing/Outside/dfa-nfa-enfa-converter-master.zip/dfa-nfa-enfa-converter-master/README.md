# DFA-NFA-eNFA-converter
DFA-NFA-eNFA converter for Class : *CAU-2020-2 Automata And Formal Theory - Midterm Exam Assignment1*

## Notice
- Compiled in Visual Studio 2019
- **DO NOT COPY**

## Contents
- DFA-NFA-eNFA converter
  - Symbols should be one character(char)
