# pda
This contains the code for Push Down Automata for 0^n and 1^n
Also the implementation of the PDA in various different forms.
