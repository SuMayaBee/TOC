### Regular expression to NFA in cpp

This is a cpp program to convert a given regular expression to NFA (Non finite Automata)

The final output of the program is the transition table, which gives the state change on input.
